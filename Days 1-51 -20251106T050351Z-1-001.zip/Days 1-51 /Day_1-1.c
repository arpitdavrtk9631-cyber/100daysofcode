//Q1 Write a program to input two numbers and display their sum.
#include <stdio.h>

int main() {
    int num1, num2, sum;

    printf("Enter first number: ");
    scanf("%d", &num1);

    printf("Enter second number: ");
    scanf("%d", &num2);

    sum = num1 + num2;

    printf("The sum of the two number is %d\n", sum);

    return 0;
}
