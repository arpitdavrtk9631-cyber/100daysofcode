//Q87 Count spaces, digits, and special characters in a string.
#include <stdio.h>

int main() {
    char str[200];
    int i, spaces = 0, digits = 0, special = 0;

    printf("Enter a string: ");
    gets(str); 

    for(i = 0; str[i] != '\0'; i++) {
        if(str[i] == ' ')
            spaces++;
        else if(str[i] >= '0' && str[i] <= '9')
            digits++;
        else if((str[i] >= 'A' && str[i] <= 'Z') || (str[i] >= 'a' && str[i] <= 'z'))
            continue;
        else
            special++;
    }

    printf("The number of spaces in the string is: %d\n", spaces);
    printf("The number of digitsin the string is: %d\n", digits);
    printf("The number of special chracters in the string is: %d\n", special);

    return 0;
}
